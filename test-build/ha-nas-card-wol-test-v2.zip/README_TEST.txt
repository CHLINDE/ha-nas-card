HA NAS CARD — Testbuild Wake-on-LAN v2
Repository: https://github.com/CHLINDE/ha-nas-card
Branch: feature/wake-on-lan
Version: 1.25.1-wol-test.2

FILES:
  nas-card.js: full standalone Home Assistant dashboard resource; all translations embedded.
  README_TEST.txt: this installation and test guide.

UPDATE / TEST IN HOME ASSISTANT:
Recommended for a temporary trial:
1. Unpack the ZIP and copy nas-card.js to /config/www/nas-card-wol-test.js
2. In Settings -> Dashboards -> Resources, disable/remove the existing
   ha-nas-card JavaScript resource for the test, so it cannot load the old card.
3. Register a JavaScript module resource with:
   /local/nas-card-wol-test.js?v=2
4. Hard reload the dashboard / clear browser frontend cache.
Alternatively replace the HACS resource file temporarily and restore it afterward.
A HACS update may overwrite any manual HACS-file changes.

FRITZ!BOX TOOLS (no additional Home Assistant WOL integration needed):
1. Open Settings -> Devices & services -> FRITZ!Box Tools.
2. Enable network device tracking in FRITZ!Box Tools options.
3. Locate your NAS device, then enable its disabled-by-default
   Wake on LAN button entity.
4. The card will search for that enabled Fritz WOL button by matching
   the device's MAC address to the card option wake_mac.
   If MAC association is not present in the HA device registry,
   you can explicitly set wake_entity to the actual WOL button entity ID.

EXAMPLE FOR LINDES_NAS:
type: custom:nas-card
nas: Lindes_NAS
language: de
wake_mac: "00:11:32:5E:61:FE"

Optional explicit overrides:
# wake_entity: button.lindes_nas_wake_on_lan  # Use the real button entity ID
# online_entity: binary_sensor.lindes_nas     # Use the real Ping sensor ID

POWER STATUS:
- An existing matching Ping binary sensor is automatically found by NAS name
  or device web-interface IP/hostname.
- If no matching Ping sensor exists, online/offline is inferred from NAS telemetry.
- A stale online_entity pointing at a missing entity will not block the fallback.
- The NAS card cannot create new Home Assistant sensors or integrations.
- An integration outage can look like a powered-down NAS when telemetry is unavailable.

WAKE PRIORITY:
  UGREEN's own Wake Up button -> explicit wake_entity ->
  Fritz!Box Tools Wake on LAN button matched by MAC ->
  already-available Home Assistant wake_on_lan.send_magic_packet service.
No additional Wake on LAN integration is required when the Fritz wake button works.
If no available wake mechanism is found, the offline power control remains disabled.

The NAS must support WOL and its WOL functionality must be enabled.
This is a test build, not an official upstream release. No pull request created.
