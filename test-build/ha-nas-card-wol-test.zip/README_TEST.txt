NAS CARD / Wake-on-LAN test build
Based on CHLINDE/ha-nas-card, branch feature/wake-on-lan
Version: 1.25.1-wol-test.1

Contents:
  nas-card.js  - Standalone JavaScript card, including every translation.
                 No npm compilation or separate language files required.

INSTALL / TEST (Home Assistant):
1. Copy nas-card.js into /config/www/nas-card-wol-test.js
2. In Settings > Dashboards > Resources register:
   URL: /local/nas-card-wol-test.js
   Type: JavaScript module
3. Remove or temporarily disable any existing ha-nas-card dashboard
   resource (especially /hacsfiles/ha-nas-card/nas-card.js).
   Having two versions loaded concurrently can keep the old card active.
4. Hard-refresh the browser (Ctrl+F5) or clear frontend cache.
5. Enable the Home Assistant Wake on LAN integration and configure the
   correct MAC and optional Ping binary sensor in the NAS card editor.

Example:
type: custom:nas-card
wake_mac: "00:11:22:33:44:55"
online_entity: binary_sensor.nas_ping

IMPORTANT:
- Replace the sample MAC address and Ping entity ID with your own.
- For UGREEN, the built-in power_action_wake_up button is preferred.
- On Synology, QNAP, ASUSTOR the MAC invokes wake_on_lan.send_magic_packet.
- Wake-on-LAN must be supported and enabled on the NAS model.
- This is a test package, not an upstream official release.
- Original main branch remains unchanged. No pull request created.
- The standalone file is source-based (translations remain embedded).
