HA NAS CARD — Wake-on-LAN test v3
Fork: https://github.com/CHLINDE/ha-nas-card
Branch: feature/wake-on-lan
Version: 1.25.1-wol-test.3

The ZIP contains a self-contained nas-card.js JavaScript module
(all languages embedded) and this readme.

INSTALL
1. Copy nas-card.js to /config/www/nas-card-wol-test.js
2. Disable or remove the original NAS card dashboard resource while testing.
3. Register the URL /local/nas-card-wol-test.js?v=3 as a JavaScript module resource.
4. Hard-refresh the browser / clear the Home Assistant frontend cache.
   Do not load two different versions of the custom NAS card simultaneously.

CARD EDITOR
1. Edit an existing custom:nas-card or custom:nas-mini-card card.
2. Enable "Wake-on-LAN aktivieren" (off by default).
3. In "Wake-on-LAN-Ziel", choose an already-installed WOL button, FRITZ!Box
   wake button or legacy WOL switch, or leave the selection on "Automatisch".
4. No MAC is required for a selected WOL target. MAC is optional for automatic
   target discovery and an already installed send_magic_packet service fallback.
5. The card never installs or creates any integration or device automatically.

EXAMPLE (use the actual entity ID from your Home Assistant)
type: custom:nas-card
nas: Lindes_NAS
language: de
show_wake: true
wake_entity: button.example_nas_wake

OPTIONAL AUTODETECTION INSTEAD
type: custom:nas-card
nas: Lindes_NAS
language: de
show_wake: true
wake_mac: "02:11:22:33:44:55"  # Replace example with the correct NAS MAC

EXPLICIT DISABLE:
show_wake: false

When the NAS is offline, the restart button becomes a wake button only
if WOL has been enabled and a working wake action is available.

For UGREEN the card can use its native wake button; for FRITZ!Box Tools
enable the corresponding WOL entity in Home Assistant (disabled by default).
If the existing Home Assistant Wake on LAN integration has configured a
WOL button, it appears among the target choices. Legacy WOL switch targets
are activated using switch.turn_on, never switch.turn_off.

Online status: an explicitly configured Ping sensor, or auto-detected Ping
sensor; otherwise NAS telemetry is used. A NAS integration outage can look
like an offline NAS; using Ping is more reliable.
No Pull Request was created. This is a test ZIP, not an official release.
